def q1(name,subject):
    print("Name    : ",name)
    print("Subject : ",subject)

n=str(input("Enter Name    : "))
s=str(input("Enter Subject : "))
q1(n,s)