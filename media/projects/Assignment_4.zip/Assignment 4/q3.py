def calculation(a,b):
    add=a+b
    sub=a-b
    mul=a*b
    div=a/b
    
    print("A : ",a)
    print("B : ",b)
    print("Addition       : ",add)
    print("Subtraction    : ",sub)
    print("Multiplication : ",mul)
    print("Divison        : ",div)

a=int(input("Enter a : "))
b=int(input("Enter b : "))
calculation(a,b)