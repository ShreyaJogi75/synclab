from random import randint
print("Number : ",randint(1000,5000))