from random import shuffle
l1=["Apple","Banana","Mango","Cherry","Watermelon","Guaua","Strawberry"]
print("Before Shuffling : ",l1)
shuffle(l1)
print("After Shuffling : ",l1)