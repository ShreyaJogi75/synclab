x= lambda a,b:a+b
a=int(input("Enter any number : "))
b=int(input("Enter any number : "))
print("Sum : ",x(a,b))